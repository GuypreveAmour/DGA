// L'écran d'affichage 
let display = document.querySelector("#screen");
display.textContent = '0';

const Touches = document.querySelectorAll("button");

Touches.forEach(touche =>{
  touche.addEventListener('click',()=>{
    if(touche.id){
      if(display.textContent == '0'){
    display.textContent = touche.id;
  }else{
    display.textContent+=touche.id;
  }
    }
    console.log(display.innerHTML)
  })
})

function Calculer(){
  let resultat;
    try{
     resultat = eval(display.textContent);
     console.log(resultat.toString().length)
     display.style = 'color:lime'
     if(resultat.toString().length >16){
       resultat = resultat.toExponential(3)
     }
    } catch (err) {
   resultat = ' Maths Erreur '
 }
   display.textContent = resultat.toString();
   
}
//Effacer le screen
function clearAll() {
  display.textContent = '0'
  display.style = 'color:aliceblue'
}
//effacer progressivement un elt
function clearOne() {
  let val = display.textContent.split('');
  console.log(val)
  nval = val.pop()
  display.textContent = val.join('');
  display.style = 'color:aliceblue'
  if(val.length == '0'){
    display.textContent = '0'
  }
}


//Quelques fonctions particulière 
//Factorielle 
function fact(n) {
  if(n == 0 || n == 1){
    return 1;
  }
  return n*fact(n-1)
};

//sqrt
const sqrt = Math.sqrt;
//Trigonometriques
const sin = Math.sin,
cos = Math.cos,
tan = Math.tan,
asin = Math.asin,
acos = Math.acos,
atan = Math.atan;
//Quelques Constantes 

const π = Math.PI; //Pi
const e = Math.E; //e ≈ 2.72
const ln = Math.log;
const log = Math.log10;
const E = Math.floor;
document.querySelector(".clo").addEventListener('click',()=>{
  clearOne()
})


//Historique des calculs
//A venir...
/*function Historique() {
let Expr = display.innerText;
let Res = eval(Expr)
console.log('Expr:',Expr)
console.log('Res:',Res)
}*/

